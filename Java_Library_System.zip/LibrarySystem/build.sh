#!/bin/bash

# Norton University Library Management System - Build Script

echo "========================================="
echo "Norton University Library System"
echo "Building the project..."
echo "========================================="

# Create bin directory if it doesn't exist
mkdir -p bin

# Compile all Java files
echo "Compiling Java source files..."
javac -d bin -sourcepath src src/library/view/MainFrame.java

if [ $? -eq 0 ]; then
    echo "✓ Build successful!"
    echo ""
    echo "To run the application, execute:"
    echo "  java -cp bin library.view.MainFrame"
    echo ""
    echo "Or use: ./run.sh"
else
    echo "✗ Build failed. Please check for errors."
    exit 1
fi
