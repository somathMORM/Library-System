# Database Configuration Guide

## PostgreSQL Setup for Norton University Library System

### Step 1: Install PostgreSQL

**Windows:**
Download and install from https://www.postgresql.org/download/windows/

**macOS:**
```bash
brew install postgresql
brew services start postgresql
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

### Step 2: Create Database

1. Access PostgreSQL:
```bash
sudo -u postgres psql
```

2. Create database and user:
```sql
CREATE DATABASE library_db;
CREATE USER library_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE library_db TO library_user;
\q
```

### Step 3: Configure Application

Edit `src/library/database/DatabaseConnection.java`:

```java
private static final String URL = "jdbc:postgresql://localhost:5432/library_db";
private static final String USER = "library_user";
private static final String PASSWORD = "your_secure_password";
```

### Step 4: Add PostgreSQL JDBC Driver

Download the PostgreSQL JDBC driver from:
https://jdbc.postgresql.org/download/

Or add to your pom.xml (if using Maven):
```xml
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <version>42.6.0</version>
</dependency>
```

### Step 5: Initialize Database

The application will automatically create tables on first run. The `DatabaseInitializer` class handles this.

## Database Tables

The system creates three main tables:

1. **books** - Stores book information with cover images
2. **members** - Stores member profiles with workplace info
3. **transactions** - Tracks borrowing and returns

## Troubleshooting

### Connection Refused
- Ensure PostgreSQL service is running
- Check firewall settings
- Verify database URL and port (default: 5432)

### Authentication Failed
- Verify username and password
- Check pg_hba.conf for authentication method

### Tables Not Created
- Check console output for SQL errors
- Verify database user has CREATE privileges
- Review DatabaseInitializer.java logs

## Security Recommendations

1. **Use strong passwords** for database users
2. **Don't commit credentials** to version control
3. **Use environment variables** for sensitive data:
```java
String dbPassword = System.getenv("DB_PASSWORD");
```
4. **Restrict database access** to localhost in production
5. **Regular backups** of the database

## Backup and Restore

### Backup:
```bash
pg_dump -U library_user library_db > backup.sql
```

### Restore:
```bash
psql -U library_user library_db < backup.sql
```
