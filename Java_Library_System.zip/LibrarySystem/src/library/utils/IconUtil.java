package library.utils;

import javax.swing.*;
import java.awt.*;

public class IconUtil {
    
    // Unicode icons for the application
    public static final String DASHBOARD = "📊";
    public static final String BOOKS = "📚";
    public static final String MEMBERS = "👥";
    public static final String BORROW_RETURN = "🔄";
    public static final String SEARCH = "🔍";
    public static final String ADD = "➕";
    public static final String DELETE = "🗑️";
    public static final String EDIT = "✏️";
    public static final String SAVE = "💾";
    public static final String CANCEL = "❌";
    public static final String CHECK = "✅";
    public static final String BOOK = "📖";
    public static final String USER = "👤";
    public static final String CALENDAR = "📅";
    public static final String INFO = "ℹ️";
    public static final String WARNING = "⚠️";
    public static final String SUCCESS = "✓";
    public static final String ERROR = "✗";
    public static final String LIBRARY = "🏛️";
    
    /**
     * Creates a label with an icon and text
     */
    public static JLabel createIconLabel(String icon, String text, Font font, Color color) {
        JLabel label = new JLabel(icon + "  " + text);
        label.setFont(font);
        label.setForeground(color);
        return label;
    }
    
    /**
     * Creates a button with an icon
     */
    public static JButton createIconButton(String icon, String text, Color bg, Color fg) {
        JButton button = new JButton(icon + "  " + text);
        button.setBackground(bg);
        button.setForeground(fg);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
}
