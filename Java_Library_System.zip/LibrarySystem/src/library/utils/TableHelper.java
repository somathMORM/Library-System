package library.utils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;

/**
 * Utility class for creating styled and colored tables
 */
public class TableHelper {
    
    /**
     * Applies colored styling to a JTable
     * @param table The table to style
     * @param headerColor The color for the table header
     */
    public static void styleTable(JTable table, Color headerColor) {
        // Table font and row height
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setGridColor(new Color(220, 220, 230));
        
        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 13));
        header.setBackground(headerColor);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 38));
        
        // Selection color - lighter version of header color
        Color selectionColor = lightenColor(headerColor, 0.7f);
        table.setSelectionBackground(selectionColor);
        table.setSelectionForeground(Color.BLACK);
        
        // Alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    if (row % 2 == 0) {
                        c.setBackground(Color.WHITE);
                    } else {
                        c.setBackground(new Color(248, 249, 252));
                    }
                    c.setForeground(Color.BLACK);
                } else {
                    c.setBackground(selectionColor);
                    c.setForeground(Color.BLACK);
                }
                
                // Center alignment for numeric columns (optional)
                if (value instanceof Number) {
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.LEFT);
                }
                
                return c;
            }
        });
    }
    
    /**
     * Apply dashboard-specific table styling (Blue theme)
     */
    public static void styleDashboardTable(JTable table) {
        styleTable(table, new Color(100, 181, 246)); // Light Blue
    }
    
    /**
     * Apply books-specific table styling (Purple theme)
     */
    public static void styleBooksTable(JTable table) {
        styleTable(table, new Color(156, 39, 176)); // Purple
    }
    
    /**
     * Apply members-specific table styling (Orange theme)
     */
    public static void styleMembersTable(JTable table) {
        styleTable(table, new Color(255, 152, 0)); // Orange
    }
    
    /**
     * Apply transactions-specific table styling (Green theme)
     */
    public static void styleTransactionsTable(JTable table) {
        styleTable(table, new Color(76, 175, 80)); // Green
    }
    
    /**
     * Apply search-specific table styling (Red theme)
     */
    public static void styleSearchTable(JTable table) {
        styleTable(table, new Color(244, 67, 54)); // Red
    }
    
    /**
     * Lightens a color by a given factor
     * @param color The original color
     * @param factor Factor to lighten (0.0 to 1.0, where 1.0 is white)
     * @return Lightened color
     */
    private static Color lightenColor(Color color, float factor) {
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        
        r = Math.min(255, (int)(r + (255 - r) * factor));
        g = Math.min(255, (int)(g + (255 - g) * factor));
        b = Math.min(255, (int)(b + (255 - b) * factor));
        
        return new Color(r, g, b);
    }
    
    /**
     * Creates a scroll pane with styled scrollbars
     */
    public static JScrollPane createStyledScrollPane(JTable table) {
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 230), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);
        return scrollPane;
    }
}
