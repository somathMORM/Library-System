package library.controller;

import library.database.DatabaseConnection;
import library.model.Transaction;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TransactionController {

    public boolean borrowBook(int bookId, int memberId) {
        LocalDate borrowDate = LocalDate.now();
        LocalDate dueDate = borrowDate.plusDays(14);
        return borrowBook(bookId, memberId, borrowDate.toString(), dueDate.toString());
    }

    public boolean borrowBook(int bookId, int memberId, String borrowDateStr, String dueDateStr) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // Check availability
            String checkSql = "SELECT available_copies FROM books WHERE id=?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next() || rs.getInt("available_copies") <= 0) {
                conn.rollback();
                return false;
            }

            // Insert transaction
            LocalDate borrowDate = LocalDate.parse(borrowDateStr);
            LocalDate dueDate = LocalDate.parse(dueDateStr);
            String insertSql = "INSERT INTO transactions (book_id, member_id, borrow_date, due_date, status) VALUES (?, ?, ?, ?, 'BORROWED')";
            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
            insertStmt.setInt(1, bookId);
            insertStmt.setInt(2, memberId);
            insertStmt.setDate(3, Date.valueOf(borrowDate));
            insertStmt.setDate(4, Date.valueOf(dueDate));
            insertStmt.executeUpdate();

            // Decrease available copies
            String updateSql = "UPDATE books SET available_copies = available_copies - 1 WHERE id=?";
            PreparedStatement updateStmt = conn.prepareStatement(updateSql);
            updateStmt.setInt(1, bookId);
            updateStmt.executeUpdate();

            conn.commit();
            return true;
        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.err.println("Error borrowing book: " + e.getMessage());
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    public boolean returnBook(int transactionId) {
        return returnBook(transactionId, LocalDate.now().toString());
    }

    public boolean returnBook(int transactionId, String returnDateStr) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // Get transaction
            String getSql = "SELECT * FROM transactions WHERE id=? AND status='BORROWED'";
            PreparedStatement getStmt = conn.prepareStatement(getSql);
            getStmt.setInt(1, transactionId);
            ResultSet rs = getStmt.executeQuery();
            if (!rs.next()) {
                conn.rollback();
                return false;
            }

            int bookId = rs.getInt("book_id");
            LocalDate dueDate = rs.getDate("due_date").toLocalDate();
            LocalDate returnDate = LocalDate.parse(returnDateStr);
            double fine = 0.00;

            // Calculate fine if overdue ($1 per day)
            if (returnDate.isAfter(dueDate)) {
                long daysOverdue = dueDate.until(returnDate).getDays();
                fine = daysOverdue * 1.0;
            }

            // Update transaction
            String updateTxSql = "UPDATE transactions SET return_date=?, status='RETURNED', fine=? WHERE id=?";
            PreparedStatement updateTxStmt = conn.prepareStatement(updateTxSql);
            updateTxStmt.setDate(1, Date.valueOf(returnDate));
            updateTxStmt.setDouble(2, fine);
            updateTxStmt.setInt(3, transactionId);
            updateTxStmt.executeUpdate();

            // Increase available copies
            String updateBookSql = "UPDATE books SET available_copies = available_copies + 1 WHERE id=?";
            PreparedStatement updateBookStmt = conn.prepareStatement(updateBookSql);
            updateBookStmt.setInt(1, bookId);
            updateBookStmt.executeUpdate();

            conn.commit();
            return true;
        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.err.println("Error returning book: " + e.getMessage());
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        String sql = """
            SELECT t.*, b.title as book_title, CONCAT(m.first_name, ' ', m.last_name) as member_name
            FROM transactions t
            JOIN books b ON t.book_id = b.id
            JOIN members m ON t.member_id = m.id
            ORDER BY t.created_at DESC
        """;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                transactions.add(mapResultSetToTransaction(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching transactions: " + e.getMessage());
        }
        return transactions;
    }

    public List<Transaction> getActiveBorrowings() {
        List<Transaction> transactions = new ArrayList<>();
        String sql = """
            SELECT t.*, b.title as book_title, CONCAT(m.first_name, ' ', m.last_name) as member_name
            FROM transactions t
            JOIN books b ON t.book_id = b.id
            JOIN members m ON t.member_id = m.id
            WHERE t.status = 'BORROWED'
            ORDER BY t.due_date ASC
        """;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                transactions.add(mapResultSetToTransaction(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching active borrowings: " + e.getMessage());
        }
        return transactions;
    }

    public int getBorrowedCount() {
        String sql = "SELECT COUNT(*) FROM transactions WHERE status='BORROWED'";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getOverdueCount() {
        String sql = "SELECT COUNT(*) FROM transactions WHERE status='BORROWED' AND due_date < CURRENT_DATE";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    // ── NEW: Update a transaction record ─────────────────────────────────────
    public boolean updateTransaction(int transactionId, String borrowDate, String dueDate,
                                     String returnDate, String status, double fine) {
        String sql = "UPDATE transactions SET borrow_date=?, due_date=?, return_date=?, status=?, fine=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, java.sql.Date.valueOf(borrowDate));
            stmt.setDate(2, java.sql.Date.valueOf(dueDate));
            if (returnDate != null && !returnDate.isEmpty()) {
                stmt.setDate(3, java.sql.Date.valueOf(returnDate));
            } else {
                stmt.setNull(3, java.sql.Types.DATE);
            }
            stmt.setString(4, status);
            stmt.setDouble(5, fine);
            stmt.setInt(6, transactionId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating transaction: " + e.getMessage());
            return false;
        }
    }

    // ── NEW: Delete a transaction record ─────────────────────────────────────
    // If the transaction status is BORROWED, restores available_copies by 1.
    public boolean deleteTransaction(int transactionId) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // Check if BORROWED so we can restore available copies
            String checkSql = "SELECT book_id, status FROM transactions WHERE id=?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, transactionId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) {
                conn.rollback();
                return false;
            }
            int bookId = rs.getInt("book_id");
            String status = rs.getString("status");
            rs.close();
            checkStmt.close();

            // Delete the transaction
            String deleteSql = "DELETE FROM transactions WHERE id=?";
            PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
            deleteStmt.setInt(1, transactionId);
            deleteStmt.executeUpdate();
            deleteStmt.close();

            // Restore copy if it was still borrowed
            if ("BORROWED".equals(status)) {
                String restoreSql = "UPDATE books SET available_copies = available_copies + 1 WHERE id=?";
                PreparedStatement restoreStmt = conn.prepareStatement(restoreSql);
                restoreStmt.setInt(1, bookId);
                restoreStmt.executeUpdate();
                restoreStmt.close();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.err.println("Error deleting transaction: " + e.getMessage());
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    private Transaction mapResultSetToTransaction(ResultSet rs) throws SQLException {
        Transaction t = new Transaction();
        t.setId(rs.getInt("id"));
        t.setBookId(rs.getInt("book_id"));
        t.setMemberId(rs.getInt("member_id"));
        t.setBookTitle(rs.getString("book_title"));
        t.setMemberName(rs.getString("member_name"));
        t.setBorrowDate(rs.getDate("borrow_date").toLocalDate());
        t.setDueDate(rs.getDate("due_date").toLocalDate());
        Date returnDate = rs.getDate("return_date");
        if (returnDate != null) t.setReturnDate(returnDate.toLocalDate());
        t.setStatus(rs.getString("status"));
        t.setFine(rs.getDouble("fine"));
        return t;
    }
}