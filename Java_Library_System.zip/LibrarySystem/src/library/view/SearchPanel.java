package library.view;

import library.controller.BookController;
import library.controller.MemberController;
import library.model.Book;
import library.model.Member;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SearchPanel extends JPanel {

    private BookController bookController;
    private MemberController memberController;
    private MainFrame mainFrame;
    private JTextField searchField;
    private JTable resultTable;
    private DefaultTableModel tableModel;
    private JComboBox<String> searchTypeCombo;

    public SearchPanel(BookController bookController, MemberController memberController, MainFrame mainFrame) {
        this.bookController = bookController;
        this.memberController = memberController;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(MainFrame.BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));
        initUI();
    }

    private void initUI() {
        // Top container for tabs and header
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setBackground(MainFrame.BG);

        // Navigation tabs
        JPanel tabsPanel = createNavigationTabs();
        topContainer.add(tabsPanel, BorderLayout.NORTH);

        JPanel headerContainer = new JPanel(new BorderLayout());
        headerContainer.setBackground(new Color(232, 255, 235));
        headerContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(180, 255, 190)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel title = new JLabel("Search");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(new Color(76, 175, 80));
        headerContainer.add(title, BorderLayout.WEST);
        topContainer.add(headerContainer, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // Search controls
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchPanel.setBackground(Color.WHITE);
        searchPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 230)),
                new EmptyBorder(10, 15, 10, 15)
        ));

        searchTypeCombo = new JComboBox<>(new String[]{"Books", "Members"});
        searchTypeCombo.setFont(new Font("Arial", Font.PLAIN, 13));
        searchTypeCombo.setPreferredSize(new Dimension(120, 35));

        searchField = new JTextField();
        searchField.setFont(new Font("Arial", Font.PLAIN, 13));
        searchField.setPreferredSize(new Dimension(350, 35));
        searchField.addActionListener(e -> performSearch());

        JButton searchBtn = new JButton("🔍 Search");
        searchBtn.setBackground(MainFrame.PRIMARY);
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFont(new Font("Arial", Font.BOLD, 13));
        searchBtn.setBorderPainted(false);
        searchBtn.setFocusPainted(false);
        searchBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchBtn.setPreferredSize(new Dimension(120, 35));
        searchBtn.addActionListener(e -> performSearch());

        JButton clearBtn = new JButton("Clear");
        clearBtn.setPreferredSize(new Dimension(80, 35));
        clearBtn.addActionListener(e -> { searchField.setText(""); tableModel.setRowCount(0); });

        searchPanel.add(new JLabel("Search in:"));
        searchPanel.add(searchTypeCombo);
        searchPanel.add(new JLabel("Keyword:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(clearBtn);

        // Results table
        String[] columns = {"ID", "Title / Name", "Author / Member ID", "Genre / Email", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        resultTable = new JTable(tableModel);
        resultTable.setFont(new Font("Arial", Font.PLAIN, 13));
        resultTable.setRowHeight(32);
        resultTable.setGridColor(new Color(220, 220, 230));

        // ── Colored column headers ──────────────────────────────────────────
        final Color[] HEADER_COLORS = {
                new Color(98,   0, 238),   // ID                  – purple
                new Color(33, 150, 243),   // Title / Name        – blue
                new Color(0,  150, 136),   // Author / Member ID  – teal
                new Color(255, 152,  0),   // Genre / Email       – orange
                new Color(76, 175,  80),   // Status              – green
        };

        resultTable.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);
                if (column >= 0 && column < HEADER_COLORS.length) {
                    label.setBackground(HEADER_COLORS[column]);
                } else {
                    label.setBackground(MainFrame.PRIMARY);
                }
                label.setForeground(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, 13));
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
                label.setOpaque(true);
                return label;
            }
        });
        // ───────────────────────────────────────────────────────────────────

        // Custom renderer for alternating row colors and status column
        resultTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 255, 248));

                    if (column == 4) { // Status column
                        String status = (String) value;
                        if (status.contains("Available")) {
                            c.setForeground(new Color(76, 175, 80));
                            setFont(getFont().deriveFont(Font.BOLD));
                        } else if (status.contains("Unavailable")) {
                            c.setForeground(new Color(244, 67, 54));
                            setFont(getFont().deriveFont(Font.BOLD));
                        } else {
                            c.setForeground(new Color(33, 150, 243));
                            setFont(getFont().deriveFont(Font.PLAIN));
                        }
                    } else {
                        c.setForeground(Color.BLACK);
                        setFont(getFont().deriveFont(Font.PLAIN));
                    }
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(resultTable);

        // Results label
        JLabel resultsLabel = new JLabel("Enter a keyword and press Search.");
        resultsLabel.setFont(new Font("Arial", Font.ITALIC, 13));
        resultsLabel.setForeground(Color.GRAY);
        resultsLabel.setBorder(new EmptyBorder(8, 0, 8, 0));

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(MainFrame.BG);
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(resultsLabel, BorderLayout.CENTER);
        centerPanel.add(scrollPane, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);
    }

    private void performSearch() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search keyword.");
            return;
        }
        tableModel.setRowCount(0);
        String type = (String) searchTypeCombo.getSelectedItem();

        if ("Books".equals(type)) {
            List<Book> books = bookController.searchBooks(keyword);
            for (Book b : books) {
                tableModel.addRow(new Object[]{
                        b.getId(), b.getTitle(), b.getAuthor(),
                        b.getGenre(), b.isAvailable() ? "✅ Available" : "❌ Unavailable"
                });
            }
            if (books.isEmpty()) JOptionPane.showMessageDialog(this, "No books found for: \"" + keyword + "\"");
        } else {
            List<Member> members = memberController.searchMembers(keyword);
            for (Member m : members) {
                tableModel.addRow(new Object[]{
                        m.getId(), m.getFullName(), m.getMemberId(),
                        m.getEmail(), "Active"
                });
            }
            if (members.isEmpty()) JOptionPane.showMessageDialog(this, "No members found for: \"" + keyword + "\"");
        }
    }

    private JPanel createNavigationTabs() {
        JPanel tabsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        tabsPanel.setBackground(Color.WHITE);
        tabsPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(230, 230, 235)));

        // ── Tab definitions: label, normal color, active indicator color ───
        String[] tabs      = {"Dashboard",           "Books",              "Members",            "Borrow / Return",    "Search"};
        Color[]  tabColors = {
                new Color(98,   0, 238),   // Dashboard    – purple
                new Color(33, 150, 243),   // Books        – blue
                new Color(0,  150, 136),   // Members      – teal
                new Color(255, 152,  0),   // Borrow/Return– orange
                new Color(76, 175,  80),   // Search       – green
        };
        // ───────────────────────────────────────────────────────────────────

        String activeTab = "Search";

        for (int i = 0; i < tabs.length; i++) {
            String tab   = tabs[i];
            Color  color = tabColors[i];

            JButton tabBtn = new JButton(tab);
            tabBtn.setFont(new Font("Arial", Font.PLAIN, 14));
            tabBtn.setBorderPainted(false);
            tabBtn.setFocusPainted(false);
            tabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            tabBtn.setPreferredSize(new Dimension(180, 45));

            if (tab.equals(activeTab)) {
                tabBtn.setBackground(new Color(
                        Math.min(color.getRed()   + 210, 255),
                        Math.min(color.getGreen() + 210, 255),
                        Math.min(color.getBlue()  + 210, 255)
                )); // very light tint of the tab color
                tabBtn.setForeground(color);
                tabBtn.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, color));
                tabBtn.setFont(new Font("Arial", Font.BOLD, 14));
            } else {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(color);
                tabBtn.setBorder(BorderFactory.createEmptyBorder());
            }

            tabBtn.addActionListener(e -> mainFrame.showPanel(tab));
            tabsPanel.add(tabBtn);
        }

        return tabsPanel;
    }
}