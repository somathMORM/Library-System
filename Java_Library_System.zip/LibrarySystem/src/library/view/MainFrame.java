package library.view;

import library.controller.BookController;
import library.controller.MemberController;
import library.controller.TransactionController;
import library.database.DatabaseInitializer;
import library.utils.IconUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;

public class MainFrame extends JFrame {

    private JPanel contentPanel;
    private BookController bookController = new BookController();
    private MemberController memberController = new MemberController();
    private TransactionController transactionController = new TransactionController();
    private boolean isLoggedIn = false;
    private JButton activeButton = null;

    // Norton University Colors
    public static final Color PRIMARY = new Color(200, 150, 60);  // Gold
    public static final Color SIDEBAR_BG = new Color(30, 30, 47);
    public static final Color CARD_BG = Color.WHITE;
    public static final Color SUCCESS = new Color(76, 175, 80);
    public static final Color WARNING = new Color(255, 152, 0);
    public static final Color DANGER = new Color(244, 67, 54);
    public static final Color INFO = new Color(33, 150, 243);
    public static final Color BG = new Color(245, 245, 250);
    public static final Color PURPLE = new Color(98, 0, 238);

    public MainFrame() {
        DatabaseInitializer.initialize();
        initUI();
    }

    private void initUI() {
        setTitle("សកលវិទ្យាល័យន័រតុន - Norton University Library Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Content area
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BG);
        add(contentPanel, BorderLayout.CENTER);

        // Show login screen first
        showLogin();
        setVisible(true);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(260, 0));
        sidebar.setBackground(SIDEBAR_BG);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(20, 0, 20, 0));

        // Logo and title panel
        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setBackground(SIDEBAR_BG);
        logoPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Try to load the Norton logo
        try {
            File logoFile = new File("resources/norton_logo.png");
            if (logoFile.exists()) {
                BufferedImage img = ImageIO.read(logoFile);
                Image scaledImg = img.getScaledInstance(70, 70, Image.SCALE_SMOOTH);
                JLabel logoLabel = new JLabel(new ImageIcon(scaledImg));
                logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                logoPanel.add(logoLabel);
                logoPanel.add(Box.createRigidArea(new Dimension(0, 12)));
            }
        } catch (Exception e) {
            System.err.println("Could not load logo: " + e.getMessage());
        }

        // Title in one line with custom styling
        JLabel titleLine = new JLabel("Norton University");
        titleLine.setFont(new Font("Arial", Font.BOLD, 15));
        titleLine.setForeground(PRIMARY);
        titleLine.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(titleLine);

        logoPanel.add(Box.createRigidArea(new Dimension(0, 4)));

        JLabel subtitle = new JLabel("Library Management System");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(new Color(200, 200, 220));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(subtitle);

        logoPanel.setBorder(new EmptyBorder(10, 0, 25, 0));
        sidebar.add(logoPanel);

        // Divider
        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(240, 1));
        separator.setForeground(new Color(70, 70, 90));
        separator.setBackground(new Color(70, 70, 90));
        sidebar.add(separator);
        sidebar.add(Box.createRigidArea(new Dimension(0, 20)));

        // Navigation menu items with icons and colors
        Object[][] navItems = {
                {IconUtil.DASHBOARD, "Dashboard", new Color(100, 181, 246)},      // Light Blue
                {IconUtil.BOOKS, "Books", new Color(156, 39, 176)},                // Purple
                {IconUtil.MEMBERS, "Members", new Color(255, 152, 0)},             // Orange
                {IconUtil.BORROW_RETURN, "Borrow / Return", new Color(76, 175, 80)}, // Green
                {IconUtil.SEARCH, "Search", new Color(244, 67, 54)}                // Red
        };

        for (Object[] item : navItems) {
            JButton btn = createNavButton((String)item[0], (String)item[1], (Color)item[2]);
            btn.addActionListener(e -> {
                setActiveButton(btn);
                handleNavigation((String)item[1]);
            });
            sidebar.add(btn);
            sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        }

        // Push to bottom
        sidebar.add(Box.createVerticalGlue());

        // Footer
        JLabel footer = new JLabel("<html><center>© 2026 Norton University<br>Non-Profit System</center></html>");
        footer.setFont(new Font("Arial", Font.PLAIN, 10));
        footer.setForeground(new Color(120, 120, 140));
        footer.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(footer);

        return sidebar;
    }

    private JButton createNavButton(String icon, String text, Color accentColor) {
        JButton btn = new JButton();
        btn.setLayout(new BorderLayout(12, 0));

        // Icon label with color
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        iconLabel.setForeground(accentColor);
        iconLabel.setBorder(new EmptyBorder(0, 20, 0, 0));

        // Text label
        JLabel textLabel = new JLabel(text);
        textLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        textLabel.setForeground(new Color(180, 180, 200));

        btn.add(iconLabel, BorderLayout.WEST);
        btn.add(textLabel, BorderLayout.CENTER);

        btn.setBackground(SIDEBAR_BG);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(240, 48));
        btn.setPreferredSize(new Dimension(240, 48));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        // Store the accent color for hover effects
        btn.putClientProperty("accentColor", accentColor);
        btn.putClientProperty("iconLabel", iconLabel);
        btn.putClientProperty("textLabel", textLabel);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (btn != activeButton) {
                    btn.setBackground(new Color(50, 50, 70));
                    iconLabel.setForeground(accentColor.brighter());
                    textLabel.setForeground(Color.WHITE);
                }
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (btn != activeButton) {
                    btn.setBackground(SIDEBAR_BG);
                    iconLabel.setForeground(accentColor);
                    textLabel.setForeground(new Color(180, 180, 200));
                }
            }
        });
        return btn;
    }

    private void setActiveButton(JButton btn) {
        // Reset previous active button
        if (activeButton != null) {
            activeButton.setBackground(SIDEBAR_BG);
            JLabel prevIcon = (JLabel) activeButton.getClientProperty("iconLabel");
            JLabel prevText = (JLabel) activeButton.getClientProperty("textLabel");
            Color prevColor = (Color) activeButton.getClientProperty("accentColor");
            if (prevIcon != null) prevIcon.setForeground(prevColor);
            if (prevText != null) prevText.setForeground(new Color(180, 180, 200));
        }

        // Set new active button
        activeButton = btn;
        btn.setBackground(new Color(50, 50, 70));
        JLabel iconLabel = (JLabel) btn.getClientProperty("iconLabel");
        JLabel textLabel = (JLabel) btn.getClientProperty("textLabel");
        Color accentColor = (Color) btn.getClientProperty("accentColor");
        if (iconLabel != null) iconLabel.setForeground(accentColor.brighter());
        if (textLabel != null) textLabel.setForeground(Color.WHITE);
    }

    private void handleNavigation(String section) {
        contentPanel.removeAll();
        switch (section) {
            case "Dashboard" -> showDashboard();
            case "Books" -> contentPanel.add(new BookPanel(bookController, this), BorderLayout.CENTER);
            case "Members" -> contentPanel.add(new MemberPanel(memberController, this), BorderLayout.CENTER);
            case "Borrow / Return" -> contentPanel.add(new TransactionPanel(transactionController, bookController, memberController, this), BorderLayout.CENTER);
            case "Search" -> contentPanel.add(new SearchPanel(bookController, memberController, this), BorderLayout.CENTER);
        }
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showDashboard() {
        JPanel dashboard = new DashboardPanel(bookController, memberController, transactionController, this);
        contentPanel.add(dashboard, BorderLayout.CENTER);
    }

    public void refreshDashboard() {
        contentPanel.removeAll();
        showDashboard();
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    public void showPanel(String panelName) {
        handleNavigation(panelName);
    }

    private void showLogin() {
        contentPanel.removeAll();
        contentPanel.add(new LoginPanel(this), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    public void showDashboardAfterLogin() {
        isLoggedIn = true;
        getContentPane().removeAll();

        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BG);
        add(contentPanel, BorderLayout.CENTER);

        showDashboard();

        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new MainFrame();
        });
    }
}