package library.view;

import library.controller.BookController;
import library.controller.MemberController;
import library.controller.TransactionController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class DashboardPanel extends JPanel {
    
    private MainFrame mainFrame;

    public DashboardPanel(BookController bookController, MemberController memberController,
                          TransactionController transactionController, MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(MainFrame.BG);
        setBorder(new EmptyBorder(30, 30, 30, 30));

        // Header
        JPanel headerContainer = new JPanel(new BorderLayout());
        headerContainer.setBackground(new Color(255, 250, 235)); // Light yellow background
        headerContainer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(255, 235, 180)),
            new EmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel title = new JLabel("Dashboard");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(new Color(255, 152, 0));
        headerContainer.add(title, BorderLayout.WEST);
        add(headerContainer, BorderLayout.NORTH);

        // Stats cards
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 20, 0));
        statsPanel.setBackground(MainFrame.BG);

        int totalBooks = bookController.getTotalBooks();
        int availableBooks = bookController.getAvailableCount();
        int borrowedBooks = transactionController.getBorrowedCount();
        int overdueBooks = transactionController.getOverdueCount();
        int totalMembers = memberController.getTotalMembers();

        statsPanel.add(createStatCard("Total Books", String.valueOf(totalBooks), "📚", MainFrame.INFO));
        statsPanel.add(createStatCard("Available", String.valueOf(availableBooks), "✅", MainFrame.SUCCESS));
        statsPanel.add(createStatCard("Borrowed", String.valueOf(borrowedBooks), "🔄", MainFrame.WARNING));
        statsPanel.add(createStatCard("Overdue", String.valueOf(overdueBooks), "⚠️", MainFrame.DANGER));

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(MainFrame.BG);
        centerPanel.add(statsPanel, BorderLayout.NORTH);

        // Members stat
        JPanel memberRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        memberRow.setBackground(MainFrame.BG);
        memberRow.setBorder(new EmptyBorder(20, 0, 20, 0));
        JPanel memberCard = createStatCard("Total Members", String.valueOf(totalMembers), "👥", MainFrame.PRIMARY);
        memberCard.setPreferredSize(new Dimension(220, 110));
        memberRow.add(memberCard);
        centerPanel.add(memberRow, BorderLayout.CENTER);

        // Quick action buttons
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        actionsPanel.setBackground(MainFrame.BG);
        JLabel actLabel = new JLabel("Quick Actions:");
        actLabel.setFont(new Font("Arial", Font.BOLD, 16));
        actionsPanel.add(actLabel);

        JButton addBookBtn = createActionButton("+ Add Book", MainFrame.SUCCESS);
        addBookBtn.addActionListener(e -> mainFrame.showPanel("Books"));
        
        JButton addMemberBtn = createActionButton("+ Add Member", MainFrame.INFO);
        addMemberBtn.addActionListener(e -> mainFrame.showPanel("Members"));
        
        JButton borrowBtn = createActionButton("🔄 Borrow Book", MainFrame.PRIMARY);
        borrowBtn.addActionListener(e -> mainFrame.showPanel("Transactions"));

        actionsPanel.add(addBookBtn);
        actionsPanel.add(addMemberBtn);
        actionsPanel.add(borrowBtn);
        centerPanel.add(actionsPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);
    }

    private JPanel createStatCard(String label, String value, String icon, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, color),
            new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        card.add(iconLabel, BorderLayout.WEST);

        JPanel textPanel = new JPanel(new GridLayout(2, 1));
        textPanel.setBackground(Color.WHITE);
        textPanel.setBorder(new EmptyBorder(0, 15, 0, 0));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 28));
        valueLabel.setForeground(color);

        JLabel nameLabel = new JLabel(label);
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        nameLabel.setForeground(Color.GRAY);

        textPanel.add(valueLabel);
        textPanel.add(nameLabel);
        card.add(textPanel, BorderLayout.CENTER);

        return card;
    }

    private JButton createActionButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 13));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(160, 40));
        return btn;
    }
}
