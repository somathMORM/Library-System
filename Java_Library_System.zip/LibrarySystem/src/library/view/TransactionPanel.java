package library.view;

import library.controller.BookController;
import library.controller.MemberController;
import library.controller.TransactionController;
import library.model.Book;
import library.model.Member;
import library.model.Transaction;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TransactionPanel extends JPanel {

    private TransactionController transactionController;
    private BookController bookController;
    private MemberController memberController;
    private MainFrame mainFrame;
    private JTable transactionTable;
    private DefaultTableModel tableModel;

    public TransactionPanel(TransactionController transactionController,
                            BookController bookController, MemberController memberController, MainFrame mainFrame) {
        this.transactionController = transactionController;
        this.bookController = bookController;
        this.memberController = memberController;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(MainFrame.BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));
        initUI();
        loadTransactions();
    }

    private void initUI() {
        // Top container for tabs and header
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setBackground(MainFrame.BG);

        // Navigation tabs
        JPanel tabsPanel = createNavigationTabs();
        topContainer.add(tabsPanel, BorderLayout.NORTH);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(255, 243, 232));
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(255, 220, 180)),
                new EmptyBorder(20, 20, 20, 20)
        ));
        JLabel title = new JLabel("Borrow & Return");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(new Color(255, 152, 0));
        headerPanel.add(title, BorderLayout.WEST);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setBackground(new Color(255, 243, 232));

        JButton borrowBtn = new JButton("🔄 Borrow Book");
        borrowBtn.setBackground(MainFrame.PRIMARY);
        borrowBtn.setForeground(Color.WHITE);
        borrowBtn.setFont(new Font("Arial", Font.BOLD, 13));
        borrowBtn.setBorderPainted(false);
        borrowBtn.setFocusPainted(false);
        borrowBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        borrowBtn.setPreferredSize(new Dimension(155, 38));
        borrowBtn.addActionListener(e -> showBorrowDialog());

        JButton returnBtn = new JButton("✅ Return Book");
        returnBtn.setBackground(MainFrame.SUCCESS);
        returnBtn.setForeground(Color.WHITE);
        returnBtn.setFont(new Font("Arial", Font.BOLD, 13));
        returnBtn.setBorderPainted(false);
        returnBtn.setFocusPainted(false);
        returnBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        returnBtn.setPreferredSize(new Dimension(150, 38));
        returnBtn.addActionListener(e -> returnSelectedBook());

        btnPanel.add(borrowBtn);
        btnPanel.add(returnBtn);
        headerPanel.add(btnPanel, BorderLayout.EAST);
        topContainer.add(headerPanel, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Book Title", "Member", "Borrow Date", "Due Date", "Return Date", "Status", "Fine ($)"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        transactionTable = new JTable(tableModel);
        transactionTable.setFont(new Font("Arial", Font.PLAIN, 13));
        transactionTable.setRowHeight(32);
        transactionTable.setGridColor(new Color(220, 220, 230));

        // ── Colored column headers ──────────────────────────────────────────
        final Color[] HEADER_COLORS = {
                new Color(98,   0, 238),   // ID          – purple
                new Color(33, 150, 243),   // Book Title  – blue
                new Color(0,  150, 136),   // Member      – teal
                new Color(76, 175,  80),   // Borrow Date – green
                new Color(255, 152,  0),   // Due Date    – orange
                new Color(63,  81, 181),   // Return Date – indigo
                new Color(103,  58, 183),  // Status      – deep purple
                new Color(244,  67,  54),  // Fine ($)    – red
        };

        transactionTable.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);
                if (column >= 0 && column < HEADER_COLORS.length) {
                    label.setBackground(HEADER_COLORS[column]);
                } else {
                    label.setBackground(MainFrame.PRIMARY);
                }
                label.setForeground(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, 13));
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
                label.setOpaque(true);
                return label;
            }
        });
        // ───────────────────────────────────────────────────────────────────

        // Custom renderer for alternating row colors and status/fine columns
        transactionTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(252, 248, 255));

                    if (column == 6) { // Status column
                        String status = (String) value;
                        if (status.equals("BORROWED")) {
                            c.setForeground(new Color(255, 152, 0));
                            setFont(getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("RETURNED")) {
                            c.setForeground(new Color(76, 175, 80));
                            setFont(getFont().deriveFont(Font.BOLD));
                        }
                    } else if (column == 7) { // Fine column
                        String fine = (String) value;
                        if (!fine.equals("—")) {
                            c.setForeground(new Color(244, 67, 54));
                            setFont(getFont().deriveFont(Font.BOLD));
                        } else {
                            c.setForeground(Color.BLACK);
                            setFont(getFont().deriveFont(Font.PLAIN));
                        }
                    } else {
                        c.setForeground(Color.BLACK);
                        setFont(getFont().deriveFont(Font.PLAIN));
                    }
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(transactionTable);

        // ── Action buttons panel ────────────────────────────────────────────
        JPanel actionPanel = new JPanel(new BorderLayout());
        actionPanel.setBackground(MainFrame.BG);

        // Left: Edit & Delete
        JPanel leftBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        leftBtns.setBackground(MainFrame.BG);

        JButton editBtn = new JButton("✏️ Edit Transaction");
        editBtn.setBackground(new Color(255, 193, 7));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFont(new Font("Arial", Font.BOLD, 13));
        editBtn.setBorderPainted(false);
        editBtn.setFocusPainted(false);
        editBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        editBtn.setPreferredSize(new Dimension(175, 38));
        editBtn.addActionListener(e -> editSelectedTransaction());

        JButton deleteBtn = new JButton("🗑️ Delete Transaction");
        deleteBtn.setBackground(MainFrame.DANGER);
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFont(new Font("Arial", Font.BOLD, 13));
        deleteBtn.setBorderPainted(false);
        deleteBtn.setFocusPainted(false);
        deleteBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        deleteBtn.setPreferredSize(new Dimension(190, 38));
        deleteBtn.addActionListener(e -> deleteSelectedTransaction());

        leftBtns.add(editBtn);
        leftBtns.add(deleteBtn);

        // Right: Refresh
        JPanel rightBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        rightBtns.setBackground(MainFrame.BG);
        JButton refreshBtn = new JButton("🔃 Refresh");
        refreshBtn.setPreferredSize(new Dimension(110, 38));
        refreshBtn.addActionListener(e -> loadTransactions());
        rightBtns.add(refreshBtn);

        actionPanel.add(leftBtns, BorderLayout.WEST);
        actionPanel.add(rightBtns, BorderLayout.EAST);
        // ───────────────────────────────────────────────────────────────────

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(MainFrame.BG);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(actionPanel, BorderLayout.SOUTH);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void loadTransactions() {
        tableModel.setRowCount(0);
        List<Transaction> transactions = transactionController.getAllTransactions();
        for (Transaction t : transactions) {
            String fineDisplay = t.getFine() > 0 ? String.format("%.2f", t.getFine()) : "—";
            tableModel.addRow(new Object[]{
                    t.getId(), t.getBookTitle(), t.getMemberName(),
                    t.getBorrowDate(), t.getDueDate(),
                    t.getReturnDate() != null ? t.getReturnDate() : "—",
                    t.getStatus(),
                    fineDisplay
            });
        }
    }

    // ── Edit selected transaction ───────────────────────────────────────────
    private void editSelectedTransaction() {
        int row = transactionTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to edit.");
            return;
        }

        int    txId       = (int)    tableModel.getValueAt(row, 0);
        String bookTitle  = (String) tableModel.getValueAt(row, 1);
        String borrowDate = (String) tableModel.getValueAt(row, 3);
        String dueDate    = (String) tableModel.getValueAt(row, 4);
        String returnDate = (String) tableModel.getValueAt(row, 5);
        String status     = (String) tableModel.getValueAt(row, 6);
        String fine       = (String) tableModel.getValueAt(row, 7);

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Transaction #" + txId, true);
        dialog.setSize(420, 380);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        // Dialog header
        JPanel dialogHeader = new JPanel(new BorderLayout());
        dialogHeader.setBackground(new Color(255, 193, 7));
        dialogHeader.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel dlgTitle = new JLabel("✏️  Edit Transaction  —  " + bookTitle);
        dlgTitle.setFont(new Font("Arial", Font.BOLD, 14));
        dlgTitle.setForeground(Color.WHITE);
        dialogHeader.add(dlgTitle, BorderLayout.WEST);
        dialog.add(dialogHeader, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(5, 2, 10, 12));
        form.setBorder(new EmptyBorder(20, 20, 10, 20));

        JTextField borrowDateField = new JTextField(borrowDate);
        JTextField dueDateField    = new JTextField(dueDate);
        JTextField returnDateField = new JTextField(returnDate.equals("—") ? "" : returnDate);
        JTextField fineField       = new JTextField(fine.equals("—") ? "0.00" : fine);

        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"BORROWED", "RETURNED"});
        statusCombo.setSelectedItem(status);

        form.add(new JLabel("Borrow Date (YYYY-MM-DD):"));
        form.add(borrowDateField);
        form.add(new JLabel("Due Date (YYYY-MM-DD):"));
        form.add(dueDateField);
        form.add(new JLabel("Return Date (YYYY-MM-DD):"));
        form.add(returnDateField);
        form.add(new JLabel("Status:"));
        form.add(statusCombo);
        form.add(new JLabel("Fine ($):"));
        form.add(fineField);

        dialog.add(form, BorderLayout.CENTER);

        JButton saveBtn = new JButton("💾  Save Changes");
        saveBtn.setBackground(new Color(255, 193, 7));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.setBorderPainted(false);
        saveBtn.setFocusPainted(false);
        saveBtn.setPreferredSize(new Dimension(0, 45));
        saveBtn.addActionListener(e -> {
            String newBorrow = borrowDateField.getText().trim();
            String newDue    = dueDateField.getText().trim();
            String newReturn = returnDateField.getText().trim();
            String newStatus = (String) statusCombo.getSelectedItem();
            String newFine   = fineField.getText().trim();

            if (!isValidDate(newBorrow) || !isValidDate(newDue)) {
                JOptionPane.showMessageDialog(dialog, "Invalid borrow or due date. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!newReturn.isEmpty() && !isValidDate(newReturn)) {
                JOptionPane.showMessageDialog(dialog, "Invalid return date. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double fineValue;
            try {
                fineValue = Double.parseDouble(newFine);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Fine must be a valid number (e.g. 0.00).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (transactionController.updateTransaction(txId, newBorrow, newDue,
                    newReturn.isEmpty() ? null : newReturn, newStatus, fineValue)) {
                JOptionPane.showMessageDialog(dialog, "Transaction updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTransactions();
                mainFrame.refreshDashboard();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to update transaction.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(saveBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // ── Delete selected transaction ─────────────────────────────────────────
    private void deleteSelectedTransaction() {
        int row = transactionTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to delete.");
            return;
        }

        int    txId      = (int)    tableModel.getValueAt(row, 0);
        String bookTitle = (String) tableModel.getValueAt(row, 1);
        String member    = (String) tableModel.getValueAt(row, 2);
        String status    = (String) tableModel.getValueAt(row, 6);

        String warning = status.equals("BORROWED")
                ? "\n⚠️  Warning: This book is still marked as BORROWED.\nDeleting will free up a copy."
                : "";

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete transaction #" + txId + "?\n"
                        + "Book: "   + bookTitle + "\n"
                        + "Member: " + member
                        + warning,
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            if (transactionController.deleteTransaction(txId)) {
                JOptionPane.showMessageDialog(this, "Transaction deleted successfully.");
                loadTransactions();
                mainFrame.refreshDashboard();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete transaction.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ── Borrow dialog ───────────────────────────────────────────────────────
    private void showBorrowDialog() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Borrow a Book", true);
        dialog.setSize(450, 320);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));
        form.setBorder(new EmptyBorder(20, 20, 10, 20));

        List<Book> availableBooks = bookController.getAvailableBooks();
        JComboBox<Book> bookCombo = new JComboBox<>();
        for (Book b : availableBooks) bookCombo.addItem(b);

        List<Member> members = memberController.getAllMembers();
        JComboBox<Member> memberCombo = new JComboBox<>();
        for (Member m : members) memberCombo.addItem(m);

        JTextField borrowDateField = new JTextField();
        borrowDateField.setToolTipText("Format: YYYY-MM-DD");
        JTextField dueDateField = new JTextField();
        dueDateField.setToolTipText("Format: YYYY-MM-DD");

        form.add(new JLabel("Select Book:"));   form.add(bookCombo);
        form.add(new JLabel("Select Member:")); form.add(memberCombo);
        form.add(new JLabel("Borrow Date (YYYY-MM-DD):")); form.add(borrowDateField);
        form.add(new JLabel("Due Date (YYYY-MM-DD):")); form.add(dueDateField);

        JButton confirmBtn = new JButton("Confirm Borrow");
        confirmBtn.setBackground(MainFrame.PRIMARY);
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.setBorderPainted(false);
        confirmBtn.setPreferredSize(new Dimension(0, 42));
        confirmBtn.addActionListener(e -> {
            Book   selectedBook   = (Book)   bookCombo.getSelectedItem();
            Member selectedMember = (Member) memberCombo.getSelectedItem();
            String borrowDate = borrowDateField.getText().trim();
            String dueDate    = dueDateField.getText().trim();

            if (selectedBook == null || selectedMember == null) {
                JOptionPane.showMessageDialog(dialog, "Please select both a book and a member.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (borrowDate.isEmpty() || dueDate.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter both borrow date and due date.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!isValidDate(borrowDate) || !isValidDate(dueDate)) {
                JOptionPane.showMessageDialog(dialog, "Invalid date format. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (transactionController.borrowBook(selectedBook.getId(), selectedMember.getId(), borrowDate, dueDate)) {
                JOptionPane.showMessageDialog(dialog, "Book borrowed successfully!");
                loadTransactions();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to borrow book. It may be unavailable.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(confirmBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // ── Return dialog ───────────────────────────────────────────────────────
    private void returnSelectedBook() {
        int row = transactionTable.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Please select a transaction to return."); return; }
        String status = (String) tableModel.getValueAt(row, 6);
        if (!status.equals("BORROWED")) {
            JOptionPane.showMessageDialog(this, "This book has already been returned.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int txId = (int) tableModel.getValueAt(row, 0);
        String bookTitle = (String) tableModel.getValueAt(row, 1);

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Return Book", true);
        dialog.setSize(400, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(2, 2, 10, 10));
        form.setBorder(new EmptyBorder(20, 20, 10, 20));

        JLabel bookLabel = new JLabel("Book: " + bookTitle);
        bookLabel.setFont(new Font("Arial", Font.BOLD, 13));

        JTextField returnDateField = new JTextField();
        returnDateField.setToolTipText("Format: YYYY-MM-DD");

        form.add(bookLabel);
        form.add(new JLabel(""));
        form.add(new JLabel("Return Date (YYYY-MM-DD):"));
        form.add(returnDateField);

        JButton confirmBtn = new JButton("Confirm Return");
        confirmBtn.setBackground(MainFrame.SUCCESS);
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.setBorderPainted(false);
        confirmBtn.setPreferredSize(new Dimension(0, 42));
        confirmBtn.addActionListener(e -> {
            String returnDate = returnDateField.getText().trim();
            if (returnDate.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter the return date.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!isValidDate(returnDate)) {
                JOptionPane.showMessageDialog(dialog, "Invalid date format. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (transactionController.returnBook(txId, returnDate)) {
                JOptionPane.showMessageDialog(dialog, "Book returned successfully!");
                loadTransactions();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to return book.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(confirmBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // ── Helpers ─────────────────────────────────────────────────────────────
    private boolean isValidDate(String date) {
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) return false;
        try { java.time.LocalDate.parse(date); return true; }
        catch (Exception e) { return false; }
    }

    private JPanel createNavigationTabs() {
        JPanel tabsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        tabsPanel.setBackground(Color.WHITE);
        tabsPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(230, 230, 235)));

        String[] tabs = {"Dashboard", "Books", "Members", "Borrow / Return", "Search"};
        String activeTab = "Borrow / Return";

        for (String tab : tabs) {
            JButton tabBtn = new JButton(tab);
            tabBtn.setFont(new Font("Arial", Font.PLAIN, 14));
            tabBtn.setBorderPainted(false);
            tabBtn.setFocusPainted(false);
            tabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            tabBtn.setPreferredSize(new Dimension(180, 45));

            if (tab.equals(activeTab)) {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(MainFrame.PRIMARY);
                tabBtn.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, MainFrame.PRIMARY));
            } else {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(new Color(100, 100, 120));
                tabBtn.setBorder(BorderFactory.createEmptyBorder());
            }

            tabBtn.addActionListener(e -> mainFrame.showPanel(tab));
            tabsPanel.add(tabBtn);
        }

        return tabsPanel;
    }
}