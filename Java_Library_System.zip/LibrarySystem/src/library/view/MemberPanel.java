package library.view;

import library.controller.MemberController;
import library.model.Member;
import library.utils.IconUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MemberPanel extends JPanel {

    private MemberController memberController;
    private MainFrame mainFrame;
    private JTable memberTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public MemberPanel(MemberController memberController, MainFrame mainFrame) {
        this.memberController = memberController;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(MainFrame.BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));
        initUI();
        loadMembers();
    }

    private void initUI() {
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setBackground(MainFrame.BG);

        JPanel tabsPanel = createNavigationTabs();
        topContainer.add(tabsPanel, BorderLayout.NORTH);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(232, 245, 255));
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(180, 220, 255)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel title = new JLabel(IconUtil.MEMBERS + "  Members");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(new Color(33, 150, 243));
        headerPanel.add(title, BorderLayout.WEST);

        JButton addBtn = IconUtil.createIconButton(IconUtil.ADD, "Register Member", MainFrame.INFO, Color.WHITE);
        addBtn.setFont(new Font("Arial", Font.BOLD, 13));
        addBtn.setPreferredSize(new Dimension(180, 38));
        addBtn.addActionListener(e -> showAddMemberDialog());
        headerPanel.add(addBtn, BorderLayout.EAST);
        topContainer.add(headerPanel, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // Search
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(MainFrame.BG);
        searchField = new JTextField(30);
        searchField.setPreferredSize(new Dimension(300, 35));
        JButton searchBtn = IconUtil.createIconButton(IconUtil.SEARCH, "Search", MainFrame.PRIMARY, Color.WHITE);
        searchBtn.addActionListener(e -> searchMembers());
        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> loadMembers());
        searchPanel.add(new JLabel("Search: "));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        // Table
        String[] columns = {"ID", "Member ID", "First Name", "Last Name", "Gender", "Email", "Phone", "Workplace", "Registered"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        memberTable = new JTable(tableModel);
        memberTable.setFont(new Font("Arial", Font.PLAIN, 13));
        memberTable.setRowHeight(32);
        memberTable.setSelectionBackground(new Color(187, 222, 251));
        memberTable.setGridColor(new Color(220, 220, 230));

        // ── Colored column headers ──────────────────────────────────────────
        final Color[] HEADER_COLORS = {
                new Color(98,   0, 238),   // ID         – purple
                new Color(33, 150, 243),   // Member ID  – blue
                new Color(0,  150, 136),   // First Name – teal
                new Color(76, 175,  80),   // Last Name  – green
                new Color(255, 152,  0),   // Gender     – orange
                new Color(233,  30,  99),  // Email      – pink
                new Color(63,  81, 181),   // Phone      – indigo
                new Color(103,  58, 183),  // Workplace  – deep purple
                new Color(0,  188, 212),   // Registered – cyan
        };

        memberTable.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);
                if (column >= 0 && column < HEADER_COLORS.length) {
                    label.setBackground(HEADER_COLORS[column]);
                } else {
                    label.setBackground(MainFrame.INFO);
                }
                label.setForeground(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, 13));
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
                label.setOpaque(true);
                return label;
            }
        });
        // ───────────────────────────────────────────────────────────────────

        memberTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(245, 250, 255));
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(memberTable);

        // ── Action buttons ──────────────────────────────────────────────────
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        actionPanel.setBackground(MainFrame.BG);

        JButton editBtn = new JButton("✏️ Edit Member");
        editBtn.setBackground(new Color(255, 193, 7));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFont(new Font("Arial", Font.BOLD, 13));
        editBtn.setBorderPainted(false);
        editBtn.setFocusPainted(false);
        editBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        editBtn.setPreferredSize(new Dimension(145, 36));
        editBtn.addActionListener(e -> editSelectedMember());
        actionPanel.add(editBtn);

        JButton deleteBtn = IconUtil.createIconButton(IconUtil.DELETE, "Delete Member", MainFrame.DANGER, Color.WHITE);
        deleteBtn.addActionListener(e -> deleteSelectedMember());
        actionPanel.add(deleteBtn);
        // ───────────────────────────────────────────────────────────────────

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(MainFrame.BG);
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(actionPanel, BorderLayout.SOUTH);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void loadMembers() {
        tableModel.setRowCount(0);
        List<Member> members = memberController.getAllMembers();
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                    m.getId(),
                    m.getMemberId(),
                    m.getFirstName(),
                    m.getLastName(),
                    m.getGender(),
                    m.getEmail() != null ? m.getEmail() : "—",
                    m.getPhone(),
                    m.getWorkplace(),
                    m.getRegisteredAt() != null ? m.getRegisteredAt().substring(0, 10) : "—"
            });
        }
    }

    private void searchMembers() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) { loadMembers(); return; }
        tableModel.setRowCount(0);
        List<Member> members = memberController.searchMembers(keyword);
        for (Member m : members) {
            tableModel.addRow(new Object[]{
                    m.getId(),
                    m.getMemberId(),
                    m.getFirstName(),
                    m.getLastName(),
                    m.getGender(),
                    m.getEmail() != null ? m.getEmail() : "—",
                    m.getPhone(),
                    m.getWorkplace(),
                    m.getRegisteredAt() != null ? m.getRegisteredAt().substring(0, 10) : "—"
            });
        }
    }

    // ── Edit selected member ────────────────────────────────────────────────
    private void editSelectedMember() {
        int row = memberTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a member to edit.");
            return;
        }

        int id = (int) tableModel.getValueAt(row, 0);
        List<Member> members = memberController.getAllMembers();
        Member member = members.stream().filter(m -> m.getId() == id).findFirst().orElse(null);
        if (member == null) return;

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Member", true);
        dialog.setSize(480, 430);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        // Dialog header
        JPanel dialogHeader = new JPanel(new BorderLayout());
        dialogHeader.setBackground(new Color(255, 193, 7));
        dialogHeader.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel dlgTitle = new JLabel("✏️  Edit Member  —  " + member.getFirstName() + " " + member.getLastName());
        dlgTitle.setFont(new Font("Arial", Font.BOLD, 14));
        dlgTitle.setForeground(Color.WHITE);
        dialogHeader.add(dlgTitle, BorderLayout.WEST);
        dialog.add(dialogHeader, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(7, 2, 10, 10));
        form.setBorder(new EmptyBorder(20, 20, 10, 20));

        // Member ID is read-only
        JLabel memberIdLabel = new JLabel(member.getMemberId());
        memberIdLabel.setForeground(MainFrame.PRIMARY);
        memberIdLabel.setFont(new Font("Arial", Font.BOLD, 13));

        JTextField firstNameField  = new JTextField(member.getFirstName());
        JTextField lastNameField   = new JTextField(member.getLastName());
        JComboBox<String> genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderCombo.setSelectedItem(member.getGender());
        JTextField emailField     = new JTextField(member.getEmail() != null ? member.getEmail() : "");
        JTextField phoneField     = new JTextField(member.getPhone() != null ? member.getPhone() : "");
        JTextField workplaceField = new JTextField(member.getWorkplace() != null ? member.getWorkplace() : "");

        form.add(new JLabel("Member ID:"));        form.add(memberIdLabel);
        form.add(new JLabel("First Name:*"));      form.add(firstNameField);
        form.add(new JLabel("Last Name:*"));       form.add(lastNameField);
        form.add(new JLabel("Gender:*"));          form.add(genderCombo);
        form.add(new JLabel("Email:"));            form.add(emailField);
        form.add(new JLabel("Phone:"));            form.add(phoneField);
        form.add(new JLabel("School/Workplace:")); form.add(workplaceField);

        dialog.add(form, BorderLayout.CENTER);

        JButton saveBtn = new JButton("💾  Save Changes");
        saveBtn.setBackground(new Color(255, 193, 7));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.setBorderPainted(false);
        saveBtn.setFocusPainted(false);
        saveBtn.setPreferredSize(new Dimension(0, 45));
        saveBtn.addActionListener(e -> {
            if (firstNameField.getText().trim().isEmpty() || lastNameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "First Name and Last Name are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // ✅ Build a Member object — matches what MemberController.updateMember() expects
            Member updated = new Member(
                    member.getMemberId(),
                    firstNameField.getText().trim(),
                    lastNameField.getText().trim(),
                    (String) genderCombo.getSelectedItem(),
                    emailField.getText().trim(),
                    phoneField.getText().trim(),
                    workplaceField.getText().trim()
            );
            updated.setId(id);

            if (memberController.updateMember(updated)) {
                JOptionPane.showMessageDialog(dialog, "Member updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadMembers();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to update member.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(saveBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    // ───────────────────────────────────────────────────────────────────────

    private void showAddMemberDialog() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Register New Member", true);
        dialog.setSize(480, 480);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(8, 2, 10, 10));
        form.setBorder(new EmptyBorder(20, 20, 10, 20));

        String autoId = memberController.generateMemberId();
        JLabel memberIdLabel = new JLabel(autoId + "  (auto-generated)");
        memberIdLabel.setForeground(MainFrame.PRIMARY);
        memberIdLabel.setFont(new Font("Arial", Font.BOLD, 13));

        JTextField firstNameField  = new JTextField();
        JTextField lastNameField   = new JTextField();
        JComboBox<String> genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        JTextField emailField     = new JTextField();
        JTextField phoneField     = new JTextField();
        JTextField workplaceField = new JTextField();

        form.add(new JLabel("Member ID:*"));       form.add(memberIdLabel);
        form.add(new JLabel("First Name:*"));      form.add(firstNameField);
        form.add(new JLabel("Last Name:*"));       form.add(lastNameField);
        form.add(new JLabel("Gender:*"));          form.add(genderCombo);
        form.add(new JLabel("Email:"));            form.add(emailField);
        form.add(new JLabel("Phone:"));            form.add(phoneField);
        form.add(new JLabel("School/Workplace:")); form.add(workplaceField);

        JLabel infoLabel = new JLabel("<html><i>* Required fields</i></html>");
        infoLabel.setForeground(new Color(100, 100, 100));
        form.add(new JLabel(""));
        form.add(infoLabel);

        JButton saveBtn = IconUtil.createIconButton(IconUtil.SAVE, "Register Member", MainFrame.SUCCESS, Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.setPreferredSize(new Dimension(0, 45));
        saveBtn.addActionListener(e -> {
            if (firstNameField.getText().trim().isEmpty() || lastNameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "First Name and Last Name are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Member member = new Member(
                    autoId,
                    firstNameField.getText().trim(),
                    lastNameField.getText().trim(),
                    (String) genderCombo.getSelectedItem(),
                    emailField.getText().trim(),
                    phoneField.getText().trim(),
                    workplaceField.getText().trim()
            );

            if (memberController.addMember(member)) {
                JOptionPane.showMessageDialog(dialog,
                        "Member registered successfully!\nMember ID: " + autoId,
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                loadMembers();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog,
                        "Failed to register member. Please try again.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(saveBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void deleteSelectedMember() {
        int row = memberTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a member to delete.");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String firstName = (String) tableModel.getValueAt(row, 2);
        String lastName  = (String) tableModel.getValueAt(row, 3);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete member \"" + firstName + " " + lastName + "\"?",
                "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (memberController.deleteMember(id)) {
                JOptionPane.showMessageDialog(this, "Member deleted successfully.");
                loadMembers();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Cannot delete — member may have active transactions.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private JPanel createNavigationTabs() {
        JPanel tabsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        tabsPanel.setBackground(Color.WHITE);
        tabsPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(230, 230, 235)));

        String[] tabs = {"Dashboard", "Books", "Members", "Borrow / Return", "Search"};
        String activeTab = "Members";

        for (String tab : tabs) {
            JButton tabBtn = new JButton(tab);
            tabBtn.setFont(new Font("Arial", Font.PLAIN, 14));
            tabBtn.setBorderPainted(false);
            tabBtn.setFocusPainted(false);
            tabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            tabBtn.setPreferredSize(new Dimension(180, 45));

            if (tab.equals(activeTab)) {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(MainFrame.PRIMARY);
                tabBtn.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, MainFrame.PRIMARY));
            } else {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(new Color(100, 100, 120));
                tabBtn.setBorder(BorderFactory.createEmptyBorder());
            }

            tabBtn.addActionListener(e -> mainFrame.showPanel(tab));
            tabsPanel.add(tabBtn);
        }

        return tabsPanel;
    }
}