package library.view;

import library.controller.BookController;
import library.model.Book;
import library.utils.IconUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;
import javax.imageio.ImageIO;

public class BookPanel extends JPanel {

    private BookController bookController;
    private MainFrame mainFrame;
    private JTable bookTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private String selectedImagePath = null;

    public BookPanel(BookController bookController, MainFrame mainFrame) {
        this.bookController = bookController;
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(MainFrame.BG);
        setBorder(new EmptyBorder(25, 25, 25, 25));
        initUI();
        loadBooks();
    }

    private void initUI() {
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setBackground(MainFrame.BG);

        JPanel tabsPanel = createNavigationTabs();
        topContainer.add(tabsPanel, BorderLayout.NORTH);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(240, 235, 255));
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 180, 255)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel title = new JLabel(IconUtil.BOOKS + "  Book Catalog");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(new Color(98, 0, 238));
        headerPanel.add(title, BorderLayout.WEST);

        JButton addBtn = IconUtil.createIconButton(IconUtil.ADD, "Add New Book", MainFrame.SUCCESS, Color.WHITE);
        addBtn.setFont(new Font("Arial", Font.BOLD, 13));
        addBtn.setPreferredSize(new Dimension(160, 38));
        addBtn.addActionListener(e -> showAddBookDialog());
        headerPanel.add(addBtn, BorderLayout.EAST);
        topContainer.add(headerPanel, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // Search bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(MainFrame.BG);
        searchField = new JTextField(30);
        searchField.setPreferredSize(new Dimension(300, 35));
        searchField.setFont(new Font("Arial", Font.PLAIN, 13));
        JButton searchBtn = IconUtil.createIconButton(IconUtil.SEARCH, "Search", MainFrame.PRIMARY, Color.WHITE);
        searchBtn.addActionListener(e -> searchBooks());
        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> loadBooks());
        searchPanel.add(new JLabel("Search: "));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        // Table
        String[] columns = {"ID", "ISBN", "Title", "Author", "Genre", "Year", "Total", "Available", "Status", "Image"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        bookTable = new JTable(tableModel);
        bookTable.setFont(new Font("Arial", Font.PLAIN, 13));
        bookTable.setRowHeight(32);
        bookTable.setSelectionBackground(new Color(225, 190, 255));
        bookTable.setGridColor(new Color(220, 220, 230));

        // ── Colored column headers ──────────────────────────────────────────
        final Color[] HEADER_COLORS = {
                new Color(98,   0, 238),   // ID        – purple
                new Color(63,  81, 181),   // ISBN      – indigo
                new Color(33, 150, 243),   // Title     – blue
                new Color(0,  150, 136),   // Author    – teal
                new Color(76, 175,  80),   // Genre     – green
                new Color(255, 152,  0),   // Year      – orange
                new Color(233,  30,  99),  // Total     – pink
                new Color(244,  67,  54),  // Available – red
                new Color(103,  58, 183),  // Status    – deep purple
                new Color(0,  188, 212),   // Image     – cyan
        };

        bookTable.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);
                if (column >= 0 && column < HEADER_COLORS.length) {
                    label.setBackground(HEADER_COLORS[column]);
                } else {
                    label.setBackground(new Color(98, 0, 238));
                }
                label.setForeground(Color.WHITE);
                label.setFont(new Font("Arial", Font.BOLD, 13));
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
                label.setOpaque(true);
                return label;
            }
        });
        // ───────────────────────────────────────────────────────────────────

        bookTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(250, 247, 255));
                    c.setForeground(Color.BLACK);
                    if (column == 8) {
                        if ("Available".equals(value)) {
                            c.setForeground(MainFrame.SUCCESS);
                        } else if ("Out of Stock".equals(value)) {
                            c.setForeground(MainFrame.DANGER);
                        }
                    }
                }
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(bookTable);

        // ── Action buttons ──────────────────────────────────────────────────
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        actionPanel.setBackground(MainFrame.BG);

        JButton viewBtn = IconUtil.createIconButton(IconUtil.BOOK, "View Details", MainFrame.INFO, Color.WHITE);
        viewBtn.addActionListener(e -> viewSelectedBook());
        actionPanel.add(viewBtn);

        JButton editBtn = new JButton("✏️ Edit Book");
        editBtn.setBackground(new Color(255, 193, 7));
        editBtn.setForeground(Color.WHITE);
        editBtn.setFont(new Font("Arial", Font.BOLD, 13));
        editBtn.setBorderPainted(false);
        editBtn.setFocusPainted(false);
        editBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        editBtn.setPreferredSize(new Dimension(130, 36));
        editBtn.addActionListener(e -> editSelectedBook());
        actionPanel.add(editBtn);

        JButton deleteBtn = IconUtil.createIconButton(IconUtil.DELETE, "Delete Book", MainFrame.DANGER, Color.WHITE);
        deleteBtn.addActionListener(e -> deleteSelectedBook());
        actionPanel.add(deleteBtn);
        // ───────────────────────────────────────────────────────────────────

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(MainFrame.BG);
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(actionPanel, BorderLayout.SOUTH);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void loadBooks() {
        tableModel.setRowCount(0);
        List<Book> books = bookController.getAllBooks();
        for (Book b : books) {
            String status   = b.isAvailable() ? "Available" : "Out of Stock";
            String hasImage = (b.getImagePath() != null && !b.getImagePath().isEmpty()) ? "✓" : "—";
            tableModel.addRow(new Object[]{
                    b.getId(), b.getIsbn(), b.getTitle(), b.getAuthor(),
                    b.getGenre(), b.getPublishedYear(), b.getTotalCopies(),
                    b.getAvailableCopies(), status, hasImage
            });
        }
    }

    private void searchBooks() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) { loadBooks(); return; }
        tableModel.setRowCount(0);
        List<Book> books = bookController.searchBooks(keyword);
        for (Book b : books) {
            String status   = b.isAvailable() ? "Available" : "Out of Stock";
            String hasImage = (b.getImagePath() != null && !b.getImagePath().isEmpty()) ? "✓" : "—";
            tableModel.addRow(new Object[]{
                    b.getId(), b.getIsbn(), b.getTitle(), b.getAuthor(),
                    b.getGenre(), b.getPublishedYear(), b.getTotalCopies(),
                    b.getAvailableCopies(), status, hasImage
            });
        }
    }

    // ── Edit selected book ──────────────────────────────────────────────────
    private void editSelectedBook() {
        int row = bookTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a book to edit.");
            return;
        }

        int id = (int) tableModel.getValueAt(row, 0);
        List<Book> books = bookController.getAllBooks();
        Book book = books.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
        if (book == null) return;

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Book", true);
        dialog.setSize(650, 520);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        // Dialog header
        JPanel dialogHeader = new JPanel(new BorderLayout());
        dialogHeader.setBackground(new Color(255, 193, 7));
        dialogHeader.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel dlgTitle = new JLabel("✏️  Edit Book  —  " + book.getTitle());
        dlgTitle.setFont(new Font("Arial", Font.BOLD, 14));
        dlgTitle.setForeground(Color.WHITE);
        dialogHeader.add(dlgTitle, BorderLayout.WEST);
        dialog.add(dialogHeader, BorderLayout.NORTH);

        selectedImagePath = null;

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 10, 20));

        // Left: Image panel
        JPanel imagePanel = new JPanel(new BorderLayout(5, 5));
        imagePanel.setPreferredSize(new Dimension(180, 0));

        JLabel imageLabel = new JLabel();
        imageLabel.setPreferredSize(new Dimension(160, 220));
        imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        imageLabel.setHorizontalAlignment(JLabel.CENTER);

        // Pre-load existing image if present
        if (book.getImagePath() != null && !book.getImagePath().isEmpty()) {
            try {
                BufferedImage img = ImageIO.read(new File(book.getImagePath()));
                if (img != null) {
                    imageLabel.setIcon(new ImageIcon(img.getScaledInstance(160, 220, Image.SCALE_SMOOTH)));
                    imageLabel.setText("");
                }
            } catch (Exception ex) {
                imageLabel.setText("<html><center>Image<br>Not Found</center></html>");
                imageLabel.setForeground(Color.GRAY);
            }
        } else {
            imageLabel.setText("<html><center>No Image<br>Selected</center></html>");
            imageLabel.setForeground(Color.GRAY);
        }

        JButton selectImageBtn = new JButton("Change Image");
        selectImageBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));
            if (fc.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                try {
                    BufferedImage img = ImageIO.read(file);
                    if (img != null) {
                        imageLabel.setIcon(new ImageIcon(img.getScaledInstance(160, 220, Image.SCALE_SMOOTH)));
                        imageLabel.setText("");
                        selectedImagePath = file.getAbsolutePath();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Failed to load image: " + ex.getMessage());
                }
            }
        });

        imagePanel.add(imageLabel, BorderLayout.CENTER);
        imagePanel.add(selectImageBtn, BorderLayout.SOUTH);

        // Right: Form fields pre-filled
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));

        JTextField isbnField   = new JTextField(book.getIsbn());
        JTextField titleField  = new JTextField(book.getTitle());
        JTextField authorField = new JTextField(book.getAuthor());
        JComboBox<String> genreCombo = new JComboBox<>(new String[]{
                "Fiction", "Non-Fiction", "Science", "History", "Biography",
                "Technology", "Art", "Philosophy", "Religion", "Other"
        });
        genreCombo.setSelectedItem(book.getGenre());
        JSpinner yearSpinner   = new JSpinner(new SpinnerNumberModel(book.getPublishedYear(), 1900, 2100, 1));
        JSpinner copiesSpinner = new JSpinner(new SpinnerNumberModel(book.getTotalCopies(), 1, 100, 1));

        formPanel.add(new JLabel("ISBN:*"));          formPanel.add(isbnField);
        formPanel.add(new JLabel("Title:*"));         formPanel.add(titleField);
        formPanel.add(new JLabel("Author:*"));        formPanel.add(authorField);
        formPanel.add(new JLabel("Genre:"));          formPanel.add(genreCombo);
        formPanel.add(new JLabel("Published Year:")); formPanel.add(yearSpinner);
        formPanel.add(new JLabel("Total Copies:"));   formPanel.add(copiesSpinner);
        formPanel.add(new JLabel(""));
        JLabel infoLabel = new JLabel("<html><i>* Required fields</i></html>");
        infoLabel.setForeground(new Color(100, 100, 100));
        formPanel.add(infoLabel);

        mainPanel.add(imagePanel, BorderLayout.WEST);
        mainPanel.add(formPanel, BorderLayout.CENTER);

        JButton saveBtn = new JButton("💾  Save Changes");
        saveBtn.setBackground(new Color(255, 193, 7));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.setBorderPainted(false);
        saveBtn.setFocusPainted(false);
        saveBtn.setPreferredSize(new Dimension(0, 45));
        saveBtn.addActionListener(e -> {
            if (isbnField.getText().trim().isEmpty() ||
                    titleField.getText().trim().isEmpty() ||
                    authorField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "ISBN, Title, and Author are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Keep existing image unless a new one was selected
            String savedImagePath = book.getImagePath();
            if (selectedImagePath != null) {
                try {
                    File sourceFile = new File(selectedImagePath);
                    String fileName = System.currentTimeMillis() + "_" + sourceFile.getName();
                    File destFile = new File("resources/book_covers/" + fileName);
                    destFile.getParentFile().mkdirs();
                    Files.copy(sourceFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    savedImagePath = "resources/book_covers/" + fileName;
                } catch (Exception ex) {
                    System.err.println("Failed to copy image: " + ex.getMessage());
                }
            }

            // ✅ Build a Book object — matches what BookController.updateBook() expects
            Book updated = new Book(
                    isbnField.getText().trim(),
                    titleField.getText().trim(),
                    authorField.getText().trim(),
                    (String) genreCombo.getSelectedItem(),
                    (Integer) yearSpinner.getValue(),
                    (Integer) copiesSpinner.getValue(),
                    savedImagePath
            );
            updated.setId(id);

            if (bookController.updateBook(updated)) {
                JOptionPane.showMessageDialog(dialog, "Book updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadBooks();
                mainFrame.refreshDashboard();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to update book.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(mainPanel, BorderLayout.CENTER);
        dialog.add(saveBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    // ───────────────────────────────────────────────────────────────────────

    private void showAddBookDialog() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Add New Book", true);
        dialog.setSize(650, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        selectedImagePath = null;

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 10, 20));

        // Left: Image panel
        JPanel imagePanel = new JPanel(new BorderLayout(5, 5));
        imagePanel.setPreferredSize(new Dimension(180, 0));

        JLabel imageLabel = new JLabel();
        imageLabel.setPreferredSize(new Dimension(160, 220));
        imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setText("<html><center>No Image<br>Selected</center></html>");
        imageLabel.setForeground(Color.GRAY);

        JButton selectImageBtn = new JButton("Select Image");
        selectImageBtn.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));
            if (fileChooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try {
                    BufferedImage img = ImageIO.read(file);
                    if (img != null) {
                        Image scaled = img.getScaledInstance(160, 220, Image.SCALE_SMOOTH);
                        imageLabel.setIcon(new ImageIcon(scaled));
                        imageLabel.setText("");
                        selectedImagePath = file.getAbsolutePath();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Failed to load image: " + ex.getMessage());
                }
            }
        });

        imagePanel.add(imageLabel, BorderLayout.CENTER);
        imagePanel.add(selectImageBtn, BorderLayout.SOUTH);

        // Right: Form fields
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));

        JTextField isbnField   = new JTextField();
        JTextField titleField  = new JTextField();
        JTextField authorField = new JTextField();
        JComboBox<String> genreCombo = new JComboBox<>(new String[]{
                "Fiction", "Non-Fiction", "Science", "History", "Biography",
                "Technology", "Art", "Philosophy", "Religion", "Other"
        });
        JSpinner yearSpinner   = new JSpinner(new SpinnerNumberModel(2024, 1900, 2100, 1));
        JSpinner copiesSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));

        formPanel.add(new JLabel("ISBN:*"));          formPanel.add(isbnField);
        formPanel.add(new JLabel("Title:*"));         formPanel.add(titleField);
        formPanel.add(new JLabel("Author:*"));        formPanel.add(authorField);
        formPanel.add(new JLabel("Genre:"));          formPanel.add(genreCombo);
        formPanel.add(new JLabel("Published Year:")); formPanel.add(yearSpinner);
        formPanel.add(new JLabel("Total Copies:"));   formPanel.add(copiesSpinner);
        formPanel.add(new JLabel(""));
        JLabel infoLabel = new JLabel("<html><i>* Required fields</i></html>");
        infoLabel.setForeground(new Color(100, 100, 100));
        formPanel.add(infoLabel);

        mainPanel.add(imagePanel, BorderLayout.WEST);
        mainPanel.add(formPanel, BorderLayout.CENTER);

        JButton saveBtn = IconUtil.createIconButton(IconUtil.SAVE, "Add Book", MainFrame.SUCCESS, Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.setPreferredSize(new Dimension(0, 45));
        saveBtn.addActionListener(e -> {
            if (isbnField.getText().trim().isEmpty() ||
                    titleField.getText().trim().isEmpty() ||
                    authorField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "ISBN, Title, and Author are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String savedImagePath = null;
            if (selectedImagePath != null) {
                try {
                    File sourceFile = new File(selectedImagePath);
                    String fileName = System.currentTimeMillis() + "_" + sourceFile.getName();
                    File destFile = new File("resources/book_covers/" + fileName);
                    destFile.getParentFile().mkdirs();
                    Files.copy(sourceFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    savedImagePath = "resources/book_covers/" + fileName;
                } catch (Exception ex) {
                    System.err.println("Failed to copy image: " + ex.getMessage());
                }
            }

            Book book = new Book(
                    isbnField.getText().trim(),
                    titleField.getText().trim(),
                    authorField.getText().trim(),
                    (String) genreCombo.getSelectedItem(),
                    (Integer) yearSpinner.getValue(),
                    (Integer) copiesSpinner.getValue(),
                    savedImagePath
            );

            if (bookController.addBook(book)) {
                JOptionPane.showMessageDialog(dialog, "Book added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadBooks();
                mainFrame.refreshDashboard();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to add book. ISBN may already exist.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(mainPanel, BorderLayout.CENTER);
        dialog.add(saveBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void viewSelectedBook() {
        int row = bookTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a book to view.");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        List<Book> books = bookController.getAllBooks();
        Book book = books.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
        if (book != null) showBookDetailsDialog(book);
    }

    private void showBookDetailsDialog(Book book) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Book Details", true);
        dialog.setSize(500, 600);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        if (book.getImagePath() != null && !book.getImagePath().isEmpty()) {
            try {
                BufferedImage img = ImageIO.read(new File(book.getImagePath()));
                if (img != null) {
                    Image scaled = img.getScaledInstance(200, 280, Image.SCALE_SMOOTH);
                    JLabel imageLabel = new JLabel(new ImageIcon(scaled));
                    imageLabel.setHorizontalAlignment(JLabel.CENTER);
                    contentPanel.add(imageLabel, BorderLayout.NORTH);
                }
            } catch (Exception e) {
                System.err.println("Failed to load book image: " + e.getMessage());
            }
        }

        JPanel detailsPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        detailsPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

        detailsPanel.add(new JLabel("ISBN:"));           detailsPanel.add(new JLabel(book.getIsbn()));
        detailsPanel.add(new JLabel("Title:"));          detailsPanel.add(new JLabel(book.getTitle()));
        detailsPanel.add(new JLabel("Author:"));         detailsPanel.add(new JLabel(book.getAuthor()));
        detailsPanel.add(new JLabel("Genre:"));          detailsPanel.add(new JLabel(book.getGenre()));
        detailsPanel.add(new JLabel("Published Year:")); detailsPanel.add(new JLabel(String.valueOf(book.getPublishedYear())));
        detailsPanel.add(new JLabel("Total Copies:"));   detailsPanel.add(new JLabel(String.valueOf(book.getTotalCopies())));
        detailsPanel.add(new JLabel("Available:"));
        JLabel availLabel = new JLabel(String.valueOf(book.getAvailableCopies()));
        availLabel.setForeground(book.isAvailable() ? MainFrame.SUCCESS : MainFrame.DANGER);
        availLabel.setFont(new Font("Arial", Font.BOLD, 13));
        detailsPanel.add(availLabel);
        detailsPanel.add(new JLabel("Status:"));
        JLabel statusLabel = new JLabel(book.isAvailable() ? "Available" : "Out of Stock");
        statusLabel.setForeground(book.isAvailable() ? MainFrame.SUCCESS : MainFrame.DANGER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 13));
        detailsPanel.add(statusLabel);

        contentPanel.add(detailsPanel, BorderLayout.CENTER);

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> dialog.dispose());
        closeBtn.setPreferredSize(new Dimension(0, 40));

        dialog.add(contentPanel, BorderLayout.CENTER);
        dialog.add(closeBtn, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void deleteSelectedBook() {
        int row = bookTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a book to delete.");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String title = (String) tableModel.getValueAt(row, 2);
        int confirm = JOptionPane.showConfirmDialog(this, "Delete book \"" + title + "\"?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (bookController.deleteBook(id)) {
                JOptionPane.showMessageDialog(this, "Book deleted successfully.");
                loadBooks();
                mainFrame.refreshDashboard();
            } else {
                JOptionPane.showMessageDialog(this, "Cannot delete — book may be borrowed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private JPanel createNavigationTabs() {
        JPanel tabsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        tabsPanel.setBackground(Color.WHITE);
        tabsPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(230, 230, 235)));

        String[] tabs = {"Dashboard", "Books", "Members", "Borrow / Return", "Search"};
        String activeTab = "Books";

        for (String tab : tabs) {
            JButton tabBtn = new JButton(tab);
            tabBtn.setFont(new Font("Arial", Font.PLAIN, 14));
            tabBtn.setBorderPainted(false);
            tabBtn.setFocusPainted(false);
            tabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            tabBtn.setPreferredSize(new Dimension(180, 45));

            if (tab.equals(activeTab)) {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(MainFrame.PURPLE);
                tabBtn.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, MainFrame.PURPLE));
            } else {
                tabBtn.setBackground(Color.WHITE);
                tabBtn.setForeground(new Color(100, 100, 120));
                tabBtn.setBorder(BorderFactory.createEmptyBorder());
            }

            tabBtn.addActionListener(e -> mainFrame.showPanel(tab));
            tabsPanel.add(tabBtn);
        }

        return tabsPanel;
    }
}