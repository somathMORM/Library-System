package library.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginPanel extends JPanel {
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private MainFrame mainFrame;
    
    public LoginPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 250));
        initUI();
    }
    
    private void initUI() {
        // Center panel for login form
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(new Color(245, 245, 250));
        
        JPanel loginBox = new JPanel();
        loginBox.setLayout(new BoxLayout(loginBox, BoxLayout.Y_AXIS));
        loginBox.setBackground(Color.WHITE);
        loginBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 230), 1),
            new EmptyBorder(40, 50, 40, 50)
        ));
        loginBox.setPreferredSize(new Dimension(450, 450));
        
        // Logo/Title
        JLabel logoLabel = new JLabel("📚");
        logoLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 60));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel titleLabel = new JLabel("Library Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(MainFrame.PRIMARY);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Please login to continue");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.GRAY);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        loginBox.add(logoLabel);
        loginBox.add(Box.createRigidArea(new Dimension(0, 15)));
        loginBox.add(titleLabel);
        loginBox.add(Box.createRigidArea(new Dimension(0, 5)));
        loginBox.add(subtitleLabel);
        loginBox.add(Box.createRigidArea(new Dimension(0, 40)));
        
        // Username field
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        usernameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        usernameField = new JTextField();
        usernameField.setPreferredSize(new Dimension(350, 40));
        usernameField.setMaximumSize(new Dimension(350, 40));
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        usernameField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 230)),
            new EmptyBorder(5, 10, 5, 10)
        ));
        usernameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        loginBox.add(usernameLabel);
        loginBox.add(Box.createRigidArea(new Dimension(0, 8)));
        loginBox.add(usernameField);
        loginBox.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Password field
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        passwordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(350, 40));
        passwordField.setMaximumSize(new Dimension(350, 40));
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 230)),
            new EmptyBorder(5, 10, 5, 10)
        ));
        passwordField.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        loginBox.add(passwordLabel);
        loginBox.add(Box.createRigidArea(new Dimension(0, 8)));
        loginBox.add(passwordField);
        loginBox.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(350, 45));
        loginButton.setMaximumSize(new Dimension(350, 45));
        loginButton.setFont(new Font("Arial", Font.BOLD, 15));
        loginButton.setBackground(MainFrame.PRIMARY);
        loginButton.setForeground(Color.WHITE);
        loginButton.setBorderPainted(false);
        loginButton.setFocusPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.addActionListener(e -> handleLogin());
        
        // Add Enter key listener to password field
        passwordField.addActionListener(e -> handleLogin());
        
        loginBox.add(loginButton);
        loginBox.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Info text
        JLabel infoLabel = new JLabel("Default by: admin");
        infoLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        infoLabel.setForeground(Color.GRAY);
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBox.add(infoLabel);
        
        centerPanel.add(loginBox);
        add(centerPanel, BorderLayout.CENTER);
    }
    
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Simple authentication (you can enhance this with database)
        if (username.equals("somath") && password.equals("somath123")) {
            mainFrame.showDashboardAfterLogin();
        } else {
            JOptionPane.showMessageDialog(this, 
                "Invalid username or password!", 
                "Login Failed", 
                JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
        }
    }
}
