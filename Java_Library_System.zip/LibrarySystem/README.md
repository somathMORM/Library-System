# Norton University Library Management System
## សកលវិទ្យាល័យន័រតុន

A comprehensive, non-profit Library Management System built for Norton University with modern features and Khmer language support.

## ✨ New Features

### 1. **Norton University Branding**
- University logo integrated into the sidebar
- Bilingual title (Khmer: សកលវិទ្យាល័យន័រតុន + English)
- Custom Norton University color scheme (Gold #C8964C)
- Non-profit mission statement in footer

### 2. **Enhanced Member Registration**
The member registration form now includes:
- ✅ **Auto-generated Member ID** (Format: NU00001, NU00002, etc.)
- ✅ **First Name & Last Name** (separate fields)
- ✅ **Gender Selection** (dropdown: Male, Female, Other)
- ✅ **Phone Number**
- ✅ **School/Workplace** field

### 3. **Book Catalog with Image Upload**
- ✅ **Book Cover Image Selection** - Browse and select book cover images
- ✅ **Image Preview** - See the selected image before saving
- ✅ **Image Storage** - Images are automatically copied to resources/book_covers/
- ✅ **Book Details View** - Display book information with cover image

### 4. **Module Icons**
Every module now has a distinctive icon:
- 📊 Dashboard
- 📚 Books
- 👥 Members
- 🔄 Borrow / Return
- 🔍 Search
- ➕ Add
- 🗑️ Delete
- 💾 Save
- And more!

## 🗂️ Project Structure

```
NortonLibrarySystem/
├── src/
│   └── library/
│       ├── model/
│       │   ├── Book.java (with imagePath field)
│       │   ├── Member.java (with firstName, lastName, gender, workplace)
│       │   └── Transaction.java
│       ├── view/
│       │   ├── MainFrame.java (Norton branding & logo)
│       │   ├── BookPanel.java (image selection)
│       │   ├── MemberPanel.java (enhanced registration)
│       │   ├── DashboardPanel.java
│       │   ├── TransactionPanel.java
│       │   ├── SearchPanel.java
│       │   └── LoginPanel.java
│       ├── controller/
│       │   ├── BookController.java
│       │   ├── MemberController.java
│       │   └── TransactionController.java
│       ├── database/
│       │   ├── DatabaseConnection.java
│       │   └── DatabaseInitializer.java
│       └── utils/
│           └── IconUtil.java
└── resources/
    ├── norton_logo.png (University logo)
    └── book_covers/ (Book cover images)
```

## 🗄️ Database Schema Updates

### Members Table
```sql
CREATE TABLE members (
    id SERIAL PRIMARY KEY,
    member_id VARCHAR(20) UNIQUE NOT NULL,  -- Auto-generated (NU00001)
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    gender VARCHAR(20),                      -- NEW: Male/Female/Other
    phone VARCHAR(20),
    workplace VARCHAR(255),                  -- NEW: School/workplace
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Books Table
```sql
CREATE TABLE books (
    id SERIAL PRIMARY KEY,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    published_year INT,
    total_copies INT DEFAULT 1,
    available_copies INT DEFAULT 1,
    image_path VARCHAR(500),                 -- NEW: Book cover image
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 🚀 Setup Instructions

### Prerequisites
- Java JDK 17 or higher
- PostgreSQL 12 or higher
- Maven (optional, for dependency management)

### Database Setup

1. Install PostgreSQL and create a database:
```sql
CREATE DATABASE library_db;
```

2. Update database credentials in `DatabaseConnection.java`:
```java
private static final String URL = "jdbc:postgresql://localhost:5432/library_db";
private static final String USER = "your_username";
private static final String PASSWORD = "your_password";
```

### Running the Application

1. **Compile the project:**
```bash
javac -d bin -sourcepath src src/library/view/MainFrame.java
```

2. **Run the application:**
```bash
java -cp bin library.view.MainFrame
```

OR if using an IDE (IntelliJ IDEA, Eclipse, NetBeans):
- Import the project
- Set `MainFrame.java` as the main class
- Run the project

### Initial Login
- **Default Username:** admin
- **Default Password:** admin123

(Note: Implement proper authentication as needed)

## 📱 Features Overview

### For Librarians:
1. **Dashboard** - Overview of library statistics
2. **Book Management** - Add, edit, delete books with cover images
3. **Member Management** - Register members with detailed information
4. **Transactions** - Process borrowing and returns
5. **Search** - Quick search across books and members

### For Members:
- Auto-generated unique Member ID
- Personal profile with workplace information
- Borrow history tracking

## 🎨 Design Highlights

- **Modern UI** with Material Design principles
- **Responsive layouts** that adapt to content
- **Color-coded status** (Available/Out of Stock, etc.)
- **Alternating row colors** for better readability
- **Icon-based navigation** for intuitive UX
- **Khmer font support** for university name

## 🔧 Customization

### Change Colors
Edit color constants in `MainFrame.java`:
```java
public static final Color PRIMARY = new Color(200, 150, 60);  // Gold
public static final Color SIDEBAR_BG = new Color(30, 30, 47); // Dark blue
```

### Add More Genres
Edit the genre dropdown in `BookPanel.java`:
```java
JComboBox<String> genreCombo = new JComboBox<>(new String[]{
    "Fiction", "Non-Fiction", "Science", // Add more genres here
});
```

### Member ID Format
Change the format in `MemberController.java`:
```java
return String.format("NU%05d", count); // NU00001 format
```

## 📝 Future Enhancements

- [ ] Email notifications for due dates
- [ ] Fine calculation for overdue books
- [ ] Report generation (PDF/Excel)
- [ ] Barcode scanner integration
- [ ] Mobile app version
- [ ] Online catalog access
- [ ] Book reservation system

## 🤝 Contributing

This is a non-profit educational project for Norton University. Contributions are welcome!

## 📄 License

This project is created for Norton University as a non-profit library management solution.

## 👥 Contact

For support or questions about the system, please contact the Norton University IT Department.

---

**សកលវិទ្យាល័យន័រតុន** • **Norton University**
*Non-Profit Library Management System*
