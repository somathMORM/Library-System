# Norton University Library Management System - Features Documentation

## 🎯 Overview

This enhanced library management system is specifically designed for Norton University (សកលវិទ្យាល័យន័រតុន) as a non-profit solution for managing books, members, and borrowing transactions.

---

## ✨ Key Enhancements

### 1. Norton University Branding

#### University Logo Integration
- **Location:** Sidebar header
- **File:** `resources/norton_logo.png`
- **Size:** 80x80 pixels (scaled from uploaded image)
- **Fallback:** Text-only header if logo file is unavailable

#### Bilingual Title
- **Khmer:** សកលវិទ្យាល័យន័រតុន
- **English:** Norton University Library System
- **Font:** Khmer OS Battambang for Khmer text
- **Displays in:** Window title, sidebar, and throughout the interface

#### Color Scheme
```
PRIMARY (Gold):     #C8964C (200, 150, 60)
SIDEBAR_BG:         #1E1E2F (30, 30, 47)
SUCCESS (Green):    #4CAF50 (76, 175, 80)
WARNING (Orange):   #FF9800 (255, 152, 0)
DANGER (Red):       #F44336 (244, 67, 54)
INFO (Blue):        #2196F3 (33, 150, 243)
PURPLE:             #6200EE (98, 0, 238)
```

#### Non-Profit Statement
- Displayed in sidebar footer
- Emphasizes educational mission

---

### 2. Enhanced Member Registration

#### Auto-Generated Member ID
- **Format:** NU00001, NU00002, NU00003, etc.
- **Prefix:** NU (Norton University)
- **Padding:** 5 digits with leading zeros
- **Uniqueness:** Automatically increments from database count
- **Display:** Shown as read-only in registration form

#### Registration Form Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| Member ID | Auto | Yes | Generated automatically (NU#####) |
| First Name | Text | Yes | Member's first name |
| Last Name | Text | Yes | Member's last name |
| Gender | Dropdown | Yes | Male / Female / Other |
| Phone | Text | No | Contact number |
| School/Workplace | Text | No | Educational institution or workplace |

#### Form Validation
- First Name and Last Name are required
- Member ID is auto-generated (no user input)
- Phone number is optional (can add format validation)
- Workplace is optional

#### Member Table Display
Shows: ID | Member ID | First Name | Last Name | Gender | Phone | Workplace | Registered Date

---

### 3. Book Catalog with Image Upload

#### Image Selection Feature
- **File Types:** JPG, JPEG, PNG, GIF
- **Selection:** Via file chooser dialog
- **Preview:** Real-time preview in dialog (160x220px)
- **Storage:** Copied to `resources/book_covers/` directory
- **Naming:** Timestamped to avoid conflicts (e.g., `1708123456_book.jpg`)

#### Book Registration Form

```
┌─────────────────────────────────────────┐
│ Image Preview  │  Form Fields           │
│ ┌───────────┐  │  ISBN: ___________     │
│ │           │  │  Title: __________     │
│ │   Image   │  │  Author: _________     │
│ │           │  │  Genre: [Dropdown]     │
│ │           │  │  Year: [Spinner]       │
│ └───────────┘  │  Copies: [Spinner]     │
│ [Select Image] │  * Required fields     │
└─────────────────────────────────────────┘
```

#### Book Details View
- Displays book cover image (200x280px)
- Shows all book information
- Color-coded availability status
- Accessible via "View Details" button

#### Genre Options
- Fiction
- Non-Fiction
- Science
- History
- Biography
- Technology
- Art
- Philosophy
- Religion
- Other

#### Book Table Display
Shows: ID | ISBN | Title | Author | Genre | Year | Total | Available | Status | Image (✓/—)

---

### 4. Icon System

#### Module Icons (Unicode Emojis)

| Module | Icon | Unicode |
|--------|------|---------|
| Dashboard | 📊 | U+1F4CA |
| Books | 📚 | U+1F4DA |
| Members | 👥 | U+1F465 |
| Borrow/Return | 🔄 | U+1F504 |
| Search | 🔍 | U+1F50D |
| Add | ➕ | U+2795 |
| Delete | 🗑️ | U+1F5D1 |
| Edit | ✏️ | U+270F |
| Save | 💾 | U+1F4BE |
| Cancel | ❌ | U+274C |
| Check | ✅ | U+2705 |
| Book | 📖 | U+1F4D6 |
| User | 👤 | U+1F464 |
| Calendar | 📅 | U+1F4C5 |
| Library | 🏛️ | U+1F3DB |

#### Icon Utility Class
`IconUtil.java` provides:
- Consistent icon definitions
- Helper methods for creating icon labels
- Helper methods for creating icon buttons
- Centralized icon management

---

## 📊 System Modules

### Dashboard
- Total books count
- Total members count
- Active borrowings
- Available books count
- Quick statistics
- Recent activities

### Books Module
**Features:**
- Add new books with cover images
- Edit existing books
- Delete books
- Search books (title, author, ISBN)
- View detailed book information
- Track availability status
- Genre categorization
- Publication year tracking

**Color Coding:**
- Green: Available
- Red: Out of Stock
- Alternating row colors for readability

### Members Module
**Features:**
- Register new members
- Auto-generate unique IDs
- Search members (name, ID, workplace)
- Delete members
- View member details
- Track registration dates
- Gender information
- Workplace tracking

**Search Capabilities:**
- First name
- Last name
- Member ID
- Workplace

### Borrow/Return Module
**Features:**
- Process book borrowing
- Record return dates
- Calculate due dates
- Track fine amounts
- Transaction history
- Status tracking (BORROWED/RETURNED)

### Search Module
**Features:**
- Unified search across books and members
- Advanced filtering options
- Quick lookup by various criteria
- Combined results display

---

## 🎨 UI/UX Features

### Responsive Design
- Adapts to different screen sizes
- Fluid layouts
- Scrollable content areas

### Visual Feedback
- Hover effects on buttons
- Color-coded statuses
- Loading indicators (where applicable)
- Success/Error messages

### Navigation
- Sidebar navigation
- Tab-based panel switching
- Breadcrumb indicators
- Active state highlighting

### Form Design
- Clear field labels
- Required field indicators (*)
- Input validation
- Help text where needed
- Logical field grouping

### Table Features
- Sortable columns
- Alternating row colors
- Row selection highlighting
- Horizontal scrolling for wide tables
- Header styling

---

## 🔐 Security Features

### Authentication
- Login system (basic implementation)
- Session management
- Role-based access (expandable)

### Data Validation
- Input sanitization
- Type checking
- Required field enforcement
- Unique constraint handling

### Database Security
- Parameterized queries (SQL injection prevention)
- Connection pooling
- Proper exception handling

---

## 📈 Extensibility

### Easy Customization Points

1. **Colors:** Edit constants in `MainFrame.java`
2. **Genres:** Modify dropdown in `BookPanel.java`
3. **Member ID Format:** Change in `MemberController.java`
4. **Icons:** Update `IconUtil.java`
5. **Database:** Extend schema in `DatabaseInitializer.java`

### Future Enhancement Possibilities
- Email notifications
- Fine calculation automation
- Reporting system (PDF/Excel)
- Barcode integration
- Multi-language support
- Online catalog access
- Mobile application
- Book reservation system
- Reading recommendations
- Statistics and analytics

---

## 🎓 Educational Value

### Learning Objectives
- Database design and management
- Java Swing GUI development
- MVC architecture pattern
- File I/O operations
- Image handling in Java
- Unicode and internationalization
- SQL and JDBC
- Exception handling
- Code organization

---

## 🌟 Best Practices Implemented

1. **MVC Pattern:** Clear separation of Model, View, Controller
2. **Code Reusability:** Utility classes for common functions
3. **Consistent Naming:** Clear, descriptive variable/method names
4. **Error Handling:** Try-catch blocks with meaningful messages
5. **Resource Management:** Proper closing of database connections
6. **Documentation:** Comprehensive comments and README
7. **Version Control Ready:** Organized project structure
8. **Scalability:** Modular design for easy expansion

---

## 📞 Support and Maintenance

For technical support, feature requests, or bug reports:
- Contact: Norton University IT Department
- Project: Non-Profit Library Management System
- Purpose: Educational and library management

---

**Built with ❤️ for Norton University**
**សកលវិទ្យាល័យន័រតុន**
