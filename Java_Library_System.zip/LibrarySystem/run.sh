#!/bin/bash

# Norton University Library Management System - Run Script

echo "========================================="
echo "Norton University Library System"
echo "Starting application..."
echo "========================================="

# Check if bin directory exists
if [ ! -d "bin" ]; then
    echo "Bin directory not found. Building project first..."
    ./build.sh
fi

# Run the application
java -cp bin library.view.MainFrame
